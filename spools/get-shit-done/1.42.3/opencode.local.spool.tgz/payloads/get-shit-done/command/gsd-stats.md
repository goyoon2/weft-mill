---
description: Display project statistics — phases, plans, requirements, git metrics, and timeline
requires: [phase, progress]
tools:
  read: true
  bash: true
---
<objective>
Display comprehensive project statistics including phase progress, plan execution metrics, requirements completion, git history stats, and project timeline.
</objective>

<execution_context>
@{{WEFT_PAYLOAD_DIR}}/get-shit-done/workflows/stats.md
</execution_context>

<process>
Execute end-to-end.
</process>
