---
description: Show available GSD commands and usage guide
tools:
  read: true
---
<objective>
Display the complete GSD command reference.

Output ONLY the reference content below. Do NOT add:
- Project-specific analysis
- Git status or file context
- Next-step suggestions
- Any commentary beyond the reference
</objective>

<execution_context>
@{{WEFT_PAYLOAD_DIR}}/get-shit-done/workflows/help.md
</execution_context>

<process>
Execute end-to-end.
Display the reference content directly — no additions or modifications.
</process>
