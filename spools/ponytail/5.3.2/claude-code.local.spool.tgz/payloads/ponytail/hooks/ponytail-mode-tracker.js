#!/usr/bin/env node
// ponytail — UserPromptSubmit hook to track which ponytail mode is active
// Inspects user input for /ponytail commands and writes mode to flag file

const fs = require('fs');
const path = require('path');
const { spawn } = require('child_process');
const { getClaudeDir, getDefaultMode, isDeactivationCommand, writeDefaultMode } = require('./ponytail-config');
const {
  clearMode,
  cursorRuleNotice,
  cursorRulePath,
  isCodeBuddy,
  isCodex,
  isCopilot,
  isCursor,
  isQoder,
  readMode,
  setMode,
  writeHookOutput,
} = require('./ponytail-runtime');
const { getPonytailInstructions } = require('./ponytail-instructions');

let input = '';
let done = false;

function finish() {
  if (done) return;
  done = true;
  try {
    // Strip UTF-8 BOM some shells prepend when piping (breaks JSON.parse)
    const data = JSON.parse(input.replace(/^\uFEFF/, ''));
    const prompt = (data.prompt || '').trim().toLowerCase();

    // Cursor with the always-on rule in the workspace: no hook can change or
    // switch off a rule, so answer the command with the notice instead of
    // writing a mode the rule would contradict (#817). Ordinary prompts
    // stay silent as usual.
    if (isCursor && (/^[/@$]ponytail/.test(prompt) || isDeactivationCommand(prompt))) {
      const rule = cursorRulePath();
      if (rule) {
        writeHookOutput('UserPromptSubmit', readMode() || 'off', cursorRuleNotice(rule));
        return;
      }
    }

    // Match /ponytail commands
    let modeSwitched = false;
    let deactivated = false;
    let defaultNotice = '';
    if (/^[/@$]ponytail/.test(prompt)) {
      const parts = prompt.split(/\s+/);
      const cmd = parts[0].replace(/^[@$]/, '/');
      const arg = parts[1] || '';

      let mode = null;
      let isReportOnly = false;

      // /ponytail-review is a one-shot skill, not a session level (#736).
      // Matching it here used to setMode('review'), which latched
      // INDEPENDENT_MODES for the rest of the session.
      if (cmd === '/ponytail' || cmd === '/ponytail:ponytail') {
        // `/ponytail default <mode>` persists the default to config (survives
        // restarts). Plain switches stay session-scoped ("sticks until session
        // end"), so this is the only path that writes config. review is not a
        // valid default (#377), so only off/lite/full/ultra are accepted.
        if (arg === 'default') {
          const dmode = parts[2];
          if (dmode === 'off' || dmode === 'lite' || dmode === 'full' || dmode === 'ultra') {
            writeDefaultMode(dmode);
            defaultNotice = 'PONYTAIL DEFAULT SET — new sessions start in ' + dmode + '.';
            if (!isQoder) writeHookOutput('UserPromptSubmit', dmode, defaultNotice);
          }
          // Qoder still needs this turn's ruleset: the block below folds the
          // notice into it. mode stays null, so the session level is untouched.
          if (!isQoder) return; // don't fall through to the session-mode switch
        }
        // `/ponytail band [on|off]` shows or hides the band above the Claude Code
        // prompt (hooks/band reads this flag). It outlives the session; absent = shown.
        // Other hosts have no band, so there the word stays an unknown argument.
        if (arg === 'band' && !isCopilot && !isCodex && !isQoder && !isCodeBuddy && !isCursor) {
          // `/ponytail band import`: past sessions into the board, in the background, so the prompt
          // is answered right away while the transcripts are read. Detached, it outlives this hook's
          // process.exit below.
          if (parts[2] === 'import') {
            spawn(process.execPath, [path.join(__dirname, 'ponytail-band-import.js')], { detached: true, stdio: 'ignore' });
            writeHookOutput('UserPromptSubmit', readMode() || 'off', 'PONYTAIL BAND IMPORT: past Claude Code sessions (cost, agent time, tokens) are being added to the board in the background. Open the board in a minute. Confirm in one short line.');
            return;
          }
          const flag = path.join(getClaudeDir(), '.ponytail-band');
          let hidden = false;
          try { hidden = fs.readFileSync(flag, 'utf8').trim() === 'off'; } catch (e) {}
          const show = parts[2] === 'on' ? true : parts[2] === 'off' ? false : hidden;
          if (show) {
            try { fs.unlinkSync(flag); } catch (e) {}
          } else {
            fs.mkdirSync(path.dirname(flag), { recursive: true });
            fs.writeFileSync(flag, 'off');
          }
          writeHookOutput('UserPromptSubmit', readMode() || 'off', show
            ? 'PONYTAIL BAND ON: the band shows above the prompt again. The ponytail level is unchanged. Confirm in one short line.'
            : 'PONYTAIL BAND OFF: the band above the prompt is hidden, `/ponytail band` brings it back. The ponytail level is unchanged. Confirm in one short line.');
          return;
        }
        if (arg === 'lite') mode = 'lite';
        else if (arg === 'full') mode = 'full';
        else if (arg === 'ultra') mode = 'ultra';
        else if (arg === 'off') mode = 'off';
        else if (arg === '') {
          // Bare /ponytail switches ponytail on: off → the default level (full if
          // the default is off too); already on → keep the level, report it (#639).
          const live = readMode();
          if (live && live !== 'off') {
            isReportOnly = true;
            mode = live;
          } else {
            mode = getDefaultMode() === 'off' ? 'full' : getDefaultMode();
          }
        }
      }

      if (isReportOnly) {
        // On Qoder the ruleset block below already reports; a second write
        // here would put two JSON objects on stdout.
        if (!isQoder) {
          writeHookOutput(
            'UserPromptSubmit',
            mode,
            'PONYTAIL MODE ACTIVE — level: ' + mode,
          );
        }
      } else if (mode && mode !== 'off') {
        setMode(mode);
        modeSwitched = true;
        // ponytail: Qoder needs the full ruleset every turn, so when a mode
        // switch happens we fold the confirmation into the ruleset output
        // below (one JSON on stdout) instead of emitting two separate writes.
        if (!isQoder) {
          // Cursor (#817) and Codex have no /ponytail command that would load
          // the skill body for the new level, and the SessionStart ruleset is
          // filtered to the start level, so the tracker delivers that level's
          // ruleset along with the confirmation.
          const header = 'PONYTAIL MODE CHANGED — level: ' + mode;
          writeHookOutput(
            'UserPromptSubmit',
            mode,
            (isCodex || isCursor) ? header + '\n\n' + getPonytailInstructions(mode) : header,
          );
        }
      } else if (mode === 'off') {
        if (isQoder) setMode('off');
        else clearMode();

        deactivated = true;
        writeHookOutput('UserPromptSubmit', 'off', 'PONYTAIL MODE OFF');
      }
    }

    // Detect deactivation
    if (!modeSwitched && !deactivated && isDeactivationCommand(prompt)) {
      if (isQoder) setMode('off');
      else clearMode();

      deactivated = true;
      writeHookOutput('UserPromptSubmit', 'off', 'PONYTAIL MODE OFF');
    }

    // Qoder has no SessionStart event, so UserPromptSubmit does double duty:
    // activate the default mode on first prompt (if no flag exists yet), then
    // inject the ruleset on every prompt. Claude Code/Codex do this in
    // SessionStart via ponytail-activate.js; Qoder can't, so we do it here.
    // Skip when deactivated — user just turned ponytail off.
    if (isQoder && !deactivated) {
      let currentMode = readMode();
      if (!currentMode) {
        // First prompt in session — initialize from config/env default
        currentMode = getDefaultMode();
        if (currentMode !== 'off') {
          try { setMode(currentMode); } catch (e) {}
        }
      }
      if (currentMode && currentMode !== 'off') {
        // ponytail: one JSON per invocation — mode-switch confirmation is
        // folded into the ruleset header so Qoder gets both in one write.
        const header = (defaultNotice ? defaultNotice + '\n\n' : '') + (modeSwitched
          ? 'PONYTAIL MODE CHANGED — level: ' + currentMode + '\n\n'
          : '');
        writeHookOutput('UserPromptSubmit', currentMode, header + getPonytailInstructions(currentMode));
      } else if (defaultNotice) {
        writeHookOutput('UserPromptSubmit', currentMode, defaultNotice);
      }
    }
  } catch (e) {
    // Silent fail
  }
}

process.stdin.on('data', chunk => { input += chunk; });
// Exit on 'end', not just finish(): the fallback timer below must stay ref'd
// (see #790) so it can actually fire when stdin is stuck, and a ref'd timer
// would otherwise keep the process alive for its full 1000ms on this normal
// fast path.
process.stdin.on('end', () => { finish(); process.exit(0); });

// Never hang the session. On Windows, Claude Code runs this hook through a
// PowerShell `if {}` wrapper that can swallow the piped prompt JSON, so stdin
// 'end' never fires and the hook blocks forever — freezing the session (#443).
// On error, or after a short fallback, process whatever arrived (recovering the
// mode if data came without EOF) and exit. The fallback timer MUST stay ref'd:
// on Windows a stuck ref'd stdin handle keeps the event loop alive, and an
// unref'd timer competing with it is never scheduled — so the fallback was
// dead code in exactly the #443/#790 case it exists for, and the hook hung
// until Claude Code's external 5s watchdog killed it (#790). Mirrors the
// best-effort, never-block contract the other lifecycle hooks already follow.
process.stdin.on('error', () => { finish(); process.exit(0); });
setTimeout(() => { finish(); process.exit(0); }, 1000);
