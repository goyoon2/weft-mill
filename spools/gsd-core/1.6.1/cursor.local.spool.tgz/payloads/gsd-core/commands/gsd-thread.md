<objective>
Create, list, close, or resume persistent context threads. Threads are lightweight
cross-session knowledge stores for work that spans multiple sessions but
doesn't belong to any specific phase.
</objective>

<execution_context>
@{{WEFT_PAYLOAD_DIR}}/gsd-core/workflows/thread.md
</execution_context>

<process>
Execute end-to-end.
</process>
