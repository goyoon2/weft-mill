<objective>
Extract structured learnings from completed phase artifacts (PLAN.md, SUMMARY.md, VERIFICATION.md, UAT.md, STATE.md) into a LEARNINGS.md file that captures decisions, lessons learned, patterns discovered, and surprises encountered.
</objective>

<execution_context>
@{{WEFT_PAYLOAD_DIR}}/gsd-core/workflows/extract-learnings.md
</execution_context>

Execute the extract-learnings workflow from @{{WEFT_PAYLOAD_DIR}}/gsd-core/workflows/extract-learnings.md end-to-end.
